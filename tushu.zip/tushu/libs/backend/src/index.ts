export * from './lib/backend.module';
export * from './lib/student/student.service';
