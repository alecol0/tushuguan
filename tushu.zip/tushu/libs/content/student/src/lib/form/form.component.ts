import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'shiba-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css'],
})
export class FormComponent implements OnInit {
  constructor() {
    console.log();
  }

  ngOnInit(): void {
    console.log();
  }
}
